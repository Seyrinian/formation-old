<?php

require('tags.lib.php');
require('check.lib.php');
var_dump($_POST);
$error = 0;

if (!isset($_POST['chiffre'])) $chiffre = 1;
else {
    $error = check_integer($_POST['chiffre'], 10, 1);
    if ($error == 0) $chiffre = 1;
    else $chiffre = $_POST['chiffre'];
}
$head = tag('title', 'Table de multiplication en PHP');
$head .= tag('link', null, array(
    'rel' => 'stylesheet',
    'type' => 'text/css',
    'href' => 'css/multiplication.css'
));
$chiffres = array(
    1 => 'Un', 'Deux', 'Trois', 'Quatre', 'Cinq',
    'Six', 'Sept', 'Huit', 'Neuf', 'Dix'
);
$select = select('chiffre', $chiffre, $chiffres);
$button = button('envoyer', 'envoyer', 'envoyer');
$body = tag('h3', "Table de multiplication par" . $select . $button, array(), "\n");
$body = form($body, $_SERVER['PHP_SELF']);
if ($error) $body = paragraphe(
    "ERREUR : valeur

fournie \"{$_POST['chiffre']}\" : {$ERRORS[$error]} ",
    array('class' => 'error')
);

for ($str = '', $i = 1; $i < 11; $i++) $str .= row(cell($chiffre) .
    cell('x') .
    cell($i) .
    cell('=') .
    cell($i * $chiffre));

$body .= table($str, array('id' => 'multiplication'));
echo html($body, $head);
