<?php
$ERRORS = array(
    0 => "Pas d'erreurs",
    1 => "Chaine trop courte",
    2 => "Chaine trop longue",
    3 => "Ne correspond pas a un entier",
    4 => "Trop petit",
    5 => "Trop grand",
    6 => "Option incorrecte"
);

function check_string($string, $max, $min = 0)
{
    if (strlen($string) > $max) return 2; //chaine trop longue
    if (strlen($string) < $min) return 1; //chaine trop longue
    return 0; //Chaine correcte
}

function check_integer($value, $max, $min = 0)
{
    if (!is_numeric($value)) return 3;
    if (!is_int($value + 0)) return 4;
    if ($value < $min) return 5;
    if ($value > $max) return 6;
    return 0;
}

function check_enum($value, $list, $type = 'key')
{
    if ($type == 'key') {
        if (!array_key_exists($value, $list)) return 7;
    } else {
        if (!in_array($value, $list)) return 7;
    }
    return 0;
}

function check_list($str, $list, $type = 0)
{
    foreach ($list as $index => $value) {
        if (($type == 0 or $type == 2) and $str == $value) return 0;
        if (($type == 0 or $type == 1) and $str == $value) return 0;
    }
    return 1;
}
