<?php
require 'tags.lib.php';

echo tag('h1', "Ceci est une page de test");

echo p('Test de la fonction paragraphe');

echo a('Test de la fonction lien sur elle-même');
echo '<br>';
echo a('Test de la fonction lien sur un lien google', 'https://google.fr');


$formContent = label('testInput', 'Label de test');
$formContent .= input('testInput');
echo form($formContent);
