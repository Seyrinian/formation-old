<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Formulaire TP1 </title>
</head>

<body>
    <form method="POST" action='tableau.php'>
        <label for="nom">Nom</label>
        <input type="TEXT" name="nom" />
        <label for="prenom">Prénom</label>
        <input type="TEXT" name="prenom" />
        <label for="age">Âge</label>
        <input type="TEXT" name="age" />
        <label for="genre">Genre</label>
        <input type="RADIO" name="genre" value="M">Masculin</input>
        <input type="RADIO" name="genre" value="F">Féminin</input>
        <select name="couleur">
            <option value="bleu">Bleu</option>
            <option value="rouge">Rouge</option>
            <option value="vert">Vert</option>
            <option value="jaune">Jaune</option>
            <option value="noir">Noir</option>
        </select>
        <label for="html">HTML</label>
        <input type="CHECKBOX" name="html" />
        <input type="SUBMIT" name"envoyer" />
    </form>
</body>

</html>