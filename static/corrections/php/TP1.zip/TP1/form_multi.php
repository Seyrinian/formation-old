<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Table de mutliplication </title>
</head>

<body>
    <h1> Table de Multiplication </h1>
    <form method=POST action='multiplication.php'>
        <h2>Choisissez un chiffre:</h2>
        <!-- input à la place du select <input type="text" name="nombre"></input> -->
        <select name="nombre">
            <?php
            for ($i = 0; $i < 11; $i++) {
                echo "<option value='" . $i . "'";
                if (isset($_GET['nombre']) && $i == $_GET['nombre']) echo "selected";
                echo ">" . $i . "</option>";
            }
            ?>
        </select>
        <input type="submit" name="envoyer" />
    </form>
</body>

</html>

<!--La boucle permet de créer la liste déroulante.
					Si on a déjà séléctionné un nombre et que l'on
					est revenu sur la page de base la condition IF 
					permet de mettre la liste directement sur le dernier
					nombre choisis. Elle récupère l'info par le tableau GET
					que le lien de la page multiplication a renvoyé. 
					A noter que les attributs noms sont les indice des tableaux
					GET et POST, et els attributs value leur valeur.-->