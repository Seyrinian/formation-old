<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Affichage TP1</title>
    <link rel="stylesheet" type="text/css" href="css/tableau.css" />
</head>

<body>
    <table>
        <?php
        var_dump($_POST);
        //Le foreach associe chaque entete NOM, PRENOM, AGE, ... à la variable question, et les réponses à ces questions à la variable reponse. Cela permet d'éviter de répeter le code pour la construction de chaque ligne
        foreach ($_POST as $question => $reponse) {
            echo "<tr>";
            echo "<td>$question</td>";
            echo "<td>$reponse</td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>

</html>