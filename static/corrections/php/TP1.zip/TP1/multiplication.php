<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Table de mutliplication </title>
    <link rel="stylesheet" type="text/css" href="css/multiplication.css" />
</head>

<body>
    <?php
    $nombre = $_POST['nombre'];
    echo "<h3>Table de multiplication par $nombre </h3>";
    ?>
    <table>
        <?php
        for ($i = 0; $i <= 10; $i++) {
            echo "<tr>";
            //L'opérateur Point (.) situé à laligne en dessous sert pour la concaténation
            echo "<td>$nombre</td>";
            echo "<td>x</td>";
            echo "<td>$i</td>";
            echo "<td>=</td>";
            echo "<td>" . ($i * $nombre) . "</td>";
            echo "</tr>";
        }
        //on affiche un lien renvoyant vers le formulaire.
        echo "<a href=formulaire.php?nombre=$nombre>Retour</a>";
        ?>
    </table>
</body>

</html>