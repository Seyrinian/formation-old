<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Table de multiplication</title>
    <link rel="stylesheet" type="text/css" href="css/multiplication.css" />
</head>

<body>
    <h3>Table de multiplication par 8</h3>
    <table>
        <?php
        $n = 8;
        for ($i = 0; $i <= 10; $i++) {
            echo "<tr>";
            echo "<td>$n</td>";
            echo "<td>x</td>";
            echo "<td>$i</td>";
            echo "<td>=</td>";
            echo "<td>" . ($n * $i) . "</td>";
            echo "</tr>\n";
        }
        ?>
    </table>
</body>

</html>