<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Tables de Pythagore</title>
    <link rel="stylesheet" type="text/css" href="css/pythagore.css" />
</head>

<body>
    <h3>Tables de Pythagore </h3>

    <table>
        <?php
        echo "<tr>";
        for ($i = 1; $i <= 10; $i++) {
            echo "<th>$i</th>";
        }
        echo "</tr>";
        for ($i = 2; $i <= 10; $i++) {
            echo "<tr>";
            echo "<th>$i</th>";
            for ($j = 2; $j <= 10; $j++) {
                echo "<td>" . ($j * $i) . "</td> ";
            }
        }
        echo "</tr>";
        ?>
    </table>
</body>

</html>